﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;

//namespace TestniApp.Models.Data
//{
//    public class ProductTax
//    {
//        ProductTax() { }
//        internal ProductTax(Product product, decimal tax)
//        {
//            ProductId = product.Id;
//            Product = product;
//            Tax = tax;
//        }

//        public int Id { get; set; }
//        public int ProductId { get; set; }
//        public Product Product { get; set; }
//        public decimal Tax { get; set; }
//    }
//}